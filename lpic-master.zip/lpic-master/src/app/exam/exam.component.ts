import { Component } from '@angular/core';
import { QuizService } from '../quiz.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-exam',
  templateUrl: './exam.component.html',
  styleUrls: ['./exam.component.css']
})
export class ExamComponent {
  Questions: any[] = [];
  currentIndex: number = 0;
  answer: any[] = [];
  correctAnswerZahl: number = 0;
  falseAnswerZahl: number = 0;
  filling: string = '';
  arrayfiling: string[] = [];
  multianswer: any[] = [];

  constructor(private service: QuizService, private daniel: Router) { }

  ngOnInit(): void {
    this.currentIndex = 0;
    this.service.getQuestion().subscribe(data => { this.Questions = data; });
  }


  benutzerAnswer(antwort: string): void {
    this.answer = []; 
    this.answer.push(antwort);
  }

  multikulti(option: string, event: any): void {

    console.log('multi answer:', this.multianswer)
    const mcaArray = this.multianswer;

    if (event.target.checked) {
      mcaArray.push(option);
    } else {
      const index = mcaArray.indexOf(option);
      if (index >= 0) {
        mcaArray.splice(index, 1);
      }
    }

    mcaArray.sort();
    this.multianswer = mcaArray;
    console.log(mcaArray)
  }


  choosemulti(option: string, event: any) {
    if (this.Questions[this.currentIndex].questionType === 'multiple-choice') {
      this.multikulti(option[0], event);
    }
  }

  onNext(): void {
 
    const QuestionType = this.Questions[this.currentIndex].questionType;

    if (QuestionType === 'single-choice') {
      const userAnswer = this.answer[0];
      const currentQuestionanswer = this.Questions[this.currentIndex].correctAnswer[0];

      if (currentQuestionanswer === userAnswer[0]) {
        this.correctAnswerZahl++;
        console.log('singlechoose ist richtig und correct zahl ist', this.correctAnswerZahl);
        this.currentIndex++;
      } else {
        this.falseAnswerZahl++;
        console.log('antwort ist false der Zahl istt ', this.falseAnswerZahl)
      }
    }
    if (QuestionType === 'multiple-choice') {
      const usermultiAnswer = this.multianswer;
      const currentQuestionanswer = this.Questions[this.currentIndex].correctAnswer;

      console.log('usermultiAnswer:', usermultiAnswer);
      console.log('currentQuestionanswer:', currentQuestionanswer);

      if (Array.isArray(usermultiAnswer) && Array.isArray(currentQuestionanswer)) {

        if (JSON.stringify(usermultiAnswer) === JSON.stringify(currentQuestionanswer)) {
          this.correctAnswerZahl++;
          console.log('multichoose ist richtig und correct zahl ist', this.correctAnswerZahl);
          this.currentIndex++;
        } else {
          this.falseAnswerZahl++;
          console.log('antwort ist false der Zahl istt ', this.falseAnswerZahl);
        }
      } else {
        if (usermultiAnswer === currentQuestionanswer) {
          this.correctAnswerZahl++;
          console.log('multichoose ist richtig und correct zahl ist', this.correctAnswerZahl);
          this.currentIndex++;
        } else {
          this.falseAnswerZahl++;
          console.log('antwort ist false der Zahl istt ', this.falseAnswerZahl);
        }
      }
      this.multianswer = [];
    }
    if (QuestionType === 'fill-in') {

      const currentQuestionanswer = this.Questions[this.currentIndex].correctAnswer[0];
      if (this.answer[0] === currentQuestionanswer) {
        this.correctAnswerZahl++;
        this.currentIndex++;
      }
      else {
        this.falseAnswerZahl++
      }

    }

    if (this.falseAnswerZahl > 6) {
      this.daniel.navigateByUrl('/result');
    }
  }


  onSkipBack(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
    }
  }

  dieErste(): void {
    this.currentIndex = 0;
  }

  dieLEtzte(): void {
    this.currentIndex = 119;
  }

  die20(): void {
    if (this.currentIndex + 19 < this.Questions.length - 1) {

      this.currentIndex += 20;
    }
  }

  diemin20(): void {
    if (this.currentIndex - 19 > 0) {

      this.currentIndex -= 20;
    }
  }

  onBack(): void {
    if (this.currentIndex > 0)
      this.currentIndex--;
  }
  onSkip(): void {
    if (this.currentIndex < this.Questions.length - 1) {
      this.currentIndex++;
    }
  }

}
